import { slowCypressDown } from "cypress-slow-down";

slowCypressDown(200);
var reportId;

describe("Story 1", () => {
  it("create report", { scrollBehavior: false }, () => {
    cy.visit(
      "https://cedt-se-project-dentnutz-frontend.vercel.app/api/auth/signin"
    );
    cy.get('input[id="input-email-for-credentials-provider"]').type(
      "Dentist6@test.com"
    );
    cy.get('input[id="input-password-for-credentials-provider"]').type(
      "Dentist6"
    );
    cy.get('button[type="submit"]').click();

    cy.contains("a", "Your Schedule").click();
    cy.contains("div", "Jinbei Knight of the Sea").click();
    cy.contains("button", "Create Report").click();
    cy.get(":nth-child(1) > .rounded-2xl").type("อุดฟันที่ผุ 100 ซี่");
    cy.get(":nth-child(2) > .rounded-2xl").type("ยาสีฟันเกลือ");
    cy.get(":nth-child(3) > .rounded-2xl").type(
      "แปรงฟันให้สะอาด ใช้ไหมขัดฟัน แปรงฟัน 3 เวลาหลังอาหาร"
    );

    cy.contains("button", "Create Report").click();

    cy.intercept(
      "POST",
      "https://cedt-se-project-dentnutz-backend.vercel.app/api/v1/reports"
    ).as("createReport");
    cy.wait("@createReport").then((interception) => {
      expect(interception.response.statusCode).to.equal(201);
      expect(interception.response.body.data).to.have.property("_id");
      reportId = interception.response.body.data._id;
    });
    cy.wait(3000);
    cy.contains("button", "👍 OK!").click();
  });
});

describe("Story 2", { scrollBehavior: false }, () => {
  it("patient view report", () => {
    cy.visit(
      "https://cedt-se-project-dentnutz-frontend.vercel.app/api/auth/signin"
    );
    cy.get('input[id="input-email-for-credentials-provider"]').type(
      "Patient10@test.com"
    );
    cy.get('input[id="input-password-for-credentials-provider"]').type(
      "Patient10"
    );
    cy.get('button[type="submit"]').click();
    cy.get('[href="/report"]').click();
    cy.get(`a[href="/report/${reportId}"]`).click();
    cy.wait(3000);
  });
});

describe("Story 3 & 4", { scrollBehavior: false }, () => {
  it("dentist view report", () => {
    cy.visit(
      "https://cedt-se-project-dentnutz-frontend.vercel.app/api/auth/signin"
    );
    cy.get('input[id="input-email-for-credentials-provider"]').type(
      "Dentist6@test.com"
    );
    cy.get('input[id="input-password-for-credentials-provider"]').type(
      "Dentist6"
    );
    cy.get('button[type="submit"]').click();
    cy.get('[href="/report"]').click();
    cy.get(`a[href="/report/${reportId}"]`).click();

    cy.intercept(
      "GET",
      `https://cedt-se-project-dentnutz-backend.vercel.app/api/v1/reports/${reportId}`
    ).as("getReport");
    cy.wait("@getReport").then((interception) => {
      cy.contains("button", "Edit").click();
    });

    cy.intercept(
      "GET",
      `https://cedt-se-project-dentnutz-backend.vercel.app/api/v1/reports/${reportId}`
    ).as("updateReport");
    cy.wait("@updateReport").then((interception) => {
      cy.get(":nth-child(1) > .rounded-2xl").clear().type("อุดฟันที่ผุ 10 ซี่");
      cy.get(":nth-child(2) > .rounded-2xl").clear().type("กิ่งข่อยขัดฟัน");
      cy.get('textarea[rows="4"]').clear().type("หมอน");
      cy.contains("button", "Submit").click();
    });
  });
});
